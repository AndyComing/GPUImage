//
//  ViewController.h
//  图像处理
//
//  Created by Andy on 2016/11/15.
//  Copyright © 2016年 Andy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

